package com.csc340f23.restapi;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.client.RestTemplate;
import java.util.Scanner;

/**
 * 
 * @author DuncanN
 * 
 * In this program I have modified our rest-api demo that originally had the ravenPrice() method. I changed it to 
 * the nhlTeams method and implemented reading from the API that you had put on the discussions page. I also added the feature 
 * to choose which nhl team you would like to view the full name of (location+name, usually how sports teams names are showed)
 * and put this all in a loop that will run till the user exits (with 0), also, only 39 teams in nhl history so no values are 
 * accepted above 39 or below 0. 
 */
  
@SpringBootApplication
public class RestApiApplication {

    public static void main(String[] args) {
        SpringApplication.run(RestApiApplication.class, args);
        nhlTeams();
        System.exit(0);
    }

     public static void nhlTeams() {
        try (Scanner sc = new Scanner(System.in)) {
            int userRequest;
            while (true) {
                System.out.println("Enter a number (1-39) for an NHL team, or enter 0 to stop: ");
                userRequest = sc.nextInt();

                if (userRequest == 0) {
                    System.out.println("Program stopped.");
                    break; // Exit the loop
                }

                if (userRequest >= 1 && userRequest <= 39) {
                    try {
                        String url = "https://statsapi.web.nhl.com/api/v1/franchises/?franchiseId=" + userRequest;
                        RestTemplate restTemplate = new RestTemplate();
                        ObjectMapper mapper = new ObjectMapper();

                        String jsonPrice = restTemplate.getForObject(url, String.class);
                        JsonNode root = mapper.readTree(jsonPrice);

                        // Gets the name of the team
                        String nhlName = root.findValue("teamName").asText();
                        // Gets location of team
                        String nhlLocation = root.findValue("locationName").asText();
                        // Print values
                        System.out.println("Full Team Name: " + nhlLocation + " " + nhlName);

                    } catch (JsonProcessingException ex) {
                        System.out.println("Error in retrieving data.");
                    }
                } else {
                    System.out.println("Input out of range. Please enter a valid number (1-39) or 0 to stop.");
                }
            }
        }
    }
}

